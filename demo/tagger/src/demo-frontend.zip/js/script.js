var data = {};
var aktModel = '';
var aktProb = 0.8;
var aktId = '';
var precrec = {}
var mainModel = '';

$( document ).ready(function() {
	load('hetilap', 0);
	$(".se-pre-con").fadeOut("slow");
});

function load(model, num) {
	mainModel = model;
	loadData(num);
	loadForm();
	aktId = $('#cikk-valszto').val();
	changeForm(aktId);
	countPrecRec();
	setHeaders();
}

function setHeaders() {
	$('#cim-model').text(mainModel.toUpperCase());
	if (mainModel === 'merged') {
		$('#cim-model').text('hetilap + online'.toUpperCase());
	}
	if (mainModel === 'hetilap') {
		$('#precisionLabel').text('P: ');
		$('#recallLabel').text('R: ');
		$('#tenyleg-cimke-header').text('Eredeti címkék');
		$('#predikalt-cimke-header').text('Ajánlott címkék');
	} else {
		$('#precisionLabel').text('');
		$('#recallLabel').text('');
		$('#precision').text('');
		$('#recall').text('');
		$('#tenyleg-cimke-header').text('Eredeti címkék');
		$('#predikalt-cimke-header').text('Ajánlott címkék (hetilap + online)');
	}
}

function next() {
    $("#cikk-valszto > option:selected")
        .prop("selected", false)
        .next()
        .prop("selected", true);
	var id = $('#cikk-valszto').val();
	aktId = id;
	changeForm(id);
}

function prev() {
    $("#cikk-valszto > option:selected")
        .prop("selected", false)
        .prev()
        .prop("selected", true);
	var id = $('#cikk-valszto').val();
	aktId = id;
	changeForm(id);
}

function loadnext() {
	$(".se-pre-con").show();
	var num = parseInt(aktModel.split(".")[1]);
	num++;
	if (num == 182 && mainModel === 'baseline') {
		num = 0;
	}
	
	if (num == 126 && mainModel === 'online') {
		num = 0;
	}
	
	if (num == 200 && mainModel === 'merged') {
		num = 0;
	}
	var newModel = aktModel.split(".")[0];
	load(newModel, num);
	$(".se-pre-con").fadeOut("slow");
}

function loadprev() {
	$(".se-pre-con").show();
	var num = parseInt(aktModel.split(".")[1]);
	num--;
	if (num == -1) {
		num = 181;
		if(mainModel === 'online') {
			num = 125;
		}
		
		if(mainModel === 'merged') {
			num = 199;
		}
	}
	var newModel = aktModel.split(".")[0];
	load(newModel, num);
	$(".se-pre-con").fadeOut("slow");
}

function countPrecRec() {
	if(mainModel !== 'hetilap') return;
	var dataObj = precrec[mainModel];
	var countRealTags = 25590;
	var countPredictTags = 0;
	var founded = 0;
	for( objI in dataObj ){
		aktObj = dataObj[objI]
		var predictTags = aktObj['predict'].split(" ");
		var realTags = aktObj['tags'].split(" ");		
		
		/*for (tagI in realTags) {
			tag = realTags[tagI];
			if (tag.includes("__label__") && !(tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__"))) {			
				countRealTags++;
			}
		}*/
		
		for (tagI in predictTags) {
			tag = predictTags[tagI];
			num = parseFloat(predictTags[parseInt(tagI)+1]).toFixed(3);
			if(num >= aktProb) {
				countPredictTags++;
				if (realTags.includes(tag)) {
					founded++;
				}
			}
		}
	}
	
	//console.log(founded);
	//console.log(countPredictTags);
	var precision = founded / countPredictTags;
	if (countPredictTags == 0) {
		precision = 0;
	}
	var recall = founded / countRealTags;
	if (countRealTags == 0) {
		recall = 0;
	}
	$("#precision").text(precision.toFixed(3));
	$("#recall").text(recall.toFixed(3));
}

function convertNum (num) {
	var strNum = num;
	if(num < 10) {
		strNum = '00' + num;
	} else if(num > 9 && num < 100) {
		strNum = '0' + num;
	}
	return strNum;
}

function loadData(num) {
	aktModel = mainModel + '.' + convertNum(num);
	if(aktModel in data) return;
	console.log(aktModel + ' model is loading...');
	var rawFile = new XMLHttpRequest();
    //rawFile.open("GET", 'data/' + model + '/merged.predict.test.shuf', false);
	
    rawFile.open("GET", 'data/' + mainModel + '/split/' + aktModel, false);
    rawFile.onreadystatechange = function ()
    {
        if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
				var dataObj = {};
                var allText = rawFile.responseText;
                var splittedText = allText.trim().split("\n");
				var i = 0;
				for (line in splittedText) {
					var segments = splittedText[line].split('$$$');
					var obj = {};
					if (mainModel === 'online') {
						obj = {
							'id': i,
							'predict': segments[0].trim(),
							'egyeb': segments[1].trim(),
							'tags' : segments[2].trim(),
							'title' : segments[3].trim(),
							'text': segments[4].trim(),
							'online': segments[5].trim()
						};
					} else {
						obj = {
							'id': i,
							'predict': segments[0].trim(),
							'egyeb': segments[1].trim(),
							'tags' : segments[2].trim(),
							'title' : segments[3].trim(),
							'text': segments[4].trim()
						};
					}
					dataObj[i] = obj;
					i++;
				}
				data[aktModel] = dataObj;
            }
        }
    }
    rawFile.send(null);
	//console.log(JSON.stringify(data[model]) + ' model is loaded...');
	if (undefined != precrec.mainModel) return;
	rawFile.open("GET", 'data/' + mainModel + '/precrec.txt', false);
    rawFile.onreadystatechange = function ()
    {
		if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
				var dataObj = {};
                var allText = rawFile.responseText;
                var splittedText = allText.trim().split("\n");
				var i = 0;
				for (line in splittedText) {
					var segments = splittedText[line].split('$$$');
					var obj = {
						'id': i,
						'predict': segments[0].trim(),
						'tags' : segments[1].trim()
					};
					dataObj[i] = obj;
					i++;
				}
				
				precrec[mainModel] = dataObj;
			}
		}
	}
	rawFile.send(null);
}

function loadForm() {
	var dataObj = data[aktModel];
	var cikkValaszto = $('#cikk-valszto');
	cikkValaszto.empty();
	for (objI in dataObj) {
		aktObj = dataObj[objI];
		var id = aktObj['id'];
		var title = aktObj['title'];
		if(mainModel === 'merged') {
			if(!title.trim()) {
				title = aktObj['text'];
			}
			title = title.split('\–')[0].split('\.')[0];
			if(title.split(" ").length > 15) {
				title = title.split(" ").slice(1, 15).join(' ') + ' ...';
			}
		}
		cikkValaszto.append(
			'<option value="' + id + '">' + title + '</option>'
		);
	}

	$("#cikk-valszto option:first").attr('selected','selected');
}

function changeForm(id) {
	dataObj = data[aktModel][id];
	if(undefined === dataObj.tags) return;
	var predictTags = dataObj['predict'].split(" ");
	var realTags = dataObj['tags'].split(" ");
	var text = dataObj['text'];
	var egyebTags = dataObj['egyeb'].split(" ");
	if (mainModel === 'online') {
		var onlineTags = dataObj['online'].split(" ");
		loadTags(realTags, predictTags, egyebTags, onlineTags);
	} else {
		loadTags(realTags, predictTags, egyebTags, null);
	}
	
	$('#cikk-szoveg').text(text);
}

$('#cikk-valszto').on('change',function(){
	var id = $(this).val();
	aktId = id;
	changeForm(id);
});

$('#probRange').on('change',function(){
	var prob = $(this).val();
	var newProb = parseFloat(prob);
	aktProb = newProb;
	//var id = $( "#cikk-valszto" ).val();
	changeForm(aktId);
	$("#probValue").text(prob);
	countPrecRec();
});

$('#top3').on('change',function(){
	var id = $( "#cikk-valszto" ).val();
	changeForm(id);
});

function loadTags(realTags, predictTags, egyebTags, onlineTags) {
	var tenyleg = $('#cimke-tenyleg');
	var predikalt = $('#cimke-predikalt');
	var tenylegEgyeb = $('#cimke-tenyleg-egyeb');
	var predikaltEgyeb = $('#cimke-predikalt-egyeb');
	var predikaltOnline = $('#cimke-predikalt-online');
	tenyleg.empty();
	predikalt.empty();
	tenylegEgyeb.empty();
	predikaltEgyeb.empty();
	predikaltOnline.empty();
	var top3Checked = $("#top3").is(':checked');
	var re = new RegExp('@@', 'g');
	
	for (tagI in realTags) {
		tag = realTags[tagI];
		if (tag.includes("__label__") && !(tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__"))) {			
			tenyleg.append(
				'<li>' +
				tag.replace("__label__", "").replace(re," ") +				
				'</li>'
			);
		}
		
		if (tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__")) {
			tenylegEgyeb.append(
				'<li>' +
				tag.replace("__label__", "").replace(re," ") +
				'</li>'
			);
		}
	}

	for (tagI in predictTags) {
		tag = predictTags[tagI];
		num = parseFloat(predictTags[parseInt(tagI)+1]).toFixed(3);
		if (tag.includes("__label__") && !(tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__"))) {
			if(num >= aktProb) {
				predikalt.append(
					'<li>' +
					tag.replace("__label__", "").replace(re," ") +
					' (' + num + ')' +
					'</li>'
				);
			}
		}
	}
	
	if(mainModel === 'online') {
		predikaltOnline.append('<li>-- ONLINE --</li><li>&nbsp;</li>');
		for (tagI in onlineTags) {
			tag = onlineTags[tagI];
			num = parseFloat(onlineTags[parseInt(tagI)+1]).toFixed(3);
			if (tag.includes("__label__")) {
				if(num >= aktProb) {
					predikaltOnline.append(
						'<li>' +
						tag.replace("__label__", "").replace(re," ") +
						' (' + num + ')' +
						'</li>'
					);
				}
			}
		}
	}

	var predictTagsAdded = 0;
	if ( top3Checked && $('#cimke-predikalt li').length < 3 ) {
		predikalt.empty();
		for (tagI in predictTags) {
			tag = predictTags[tagI];
			num = parseFloat(predictTags[parseInt(tagI)+1]).toFixed(3);
			if (tag.includes("__label__") && !(tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__"))) {
				if(predictTagsAdded < 3) {
					predikalt.append(
						'<li>' +
						tag.replace("__label__", "").replace(re," ") +
						' (' + num + ')' +
						'</li>'
					);
					predictTagsAdded++;
				}
			}
		}
	}
	
	if(mainModel === 'online') {
		var predictOnlineTagsAdded = 0;
		if ( top3Checked && $('#cimke-predikalt-online li').length < 5 ) {
			predikaltOnline.empty();
			predikaltOnline.append('<li>-- ONLINE --</li><li>&nbsp;</li>');
			predictOnlineTagsAdded += 2;
			for (tagI in onlineTags) {
				tag = onlineTags[tagI];
				num = parseFloat(onlineTags[parseInt(tagI)+1]).toFixed(3);
				if (tag.includes("__label__")) {
					if(predictOnlineTagsAdded < 5) {
						predikaltOnline.append(
							'<li>' +
							tag.replace("__label__", "").replace(re," ") +
							' (' + num + ')' +
							'</li>'
						);
						predictOnlineTagsAdded++;
					}
				}
			}
		}
	}
	
	for (tagI in egyebTags) {
		tag = egyebTags[tagI];
		num = parseFloat(egyebTags[parseInt(tagI)+1]).toFixed(3);
		if (tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__")) {
			if(num >= aktProb) {
				predikaltEgyeb.append(
					'<li>' +
					tag.replace("__label__", "").replace(re," ") +
					' (' + num + ')' +
					'</li>'
				);
			}
		}
	}
	
	var predikaltEgyebAdded = 0;
	if ( top3Checked && $('#cimke-predikalt-egyeb li').length < 3 ) {
		predikaltEgyeb.empty();
		for (tagI in egyebTags) {
			tag = egyebTags[tagI];
			num = parseFloat(egyebTags[parseInt(tagI)+1]).toFixed(3);
			if (tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__")) {
				if(predikaltEgyebAdded < 3) {
					predikaltEgyeb.append(
						'<li>' +
						tag.replace("__label__", "").replace(re," ") +
						' (' + num + ')' +
						'</li>'
					);
					predikaltEgyebAdded++;
				}
			}
		}
	}
	
	if(mainModel === 'merged') {
		for (tagI in predictTags) {
			tag = predictTags[tagI];
			num = parseFloat(predictTags[parseInt(tagI)+1]).toFixed(3);
			if (tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__")) {
				if(num >= aktProb) {
					predikaltEgyeb.append(
						'<li>' +
						tag.replace("__label__", "").replace(re," ") +
						' (' + num + ')' +
						'</li>'
					);
				}
			}
		}
		
		var predictTagsEgyeb = 0;
		if ( top3Checked && $('#cimke-predikalt-egyeb li').length < 3 ) {
			predikaltEgyeb.empty();
			for (tagI in predictTags) {
				tag = predictTags[tagI];
				num = parseFloat(predictTags[parseInt(tagI)+1]).toFixed(3);
				if (tag.includes("geography__") || tag.includes("person__") || tag.includes("organization__")) {
					if(predictTagsEgyeb < 3) {
						predikaltEgyeb.append(
							'<li>' +
							tag.replace("__label__", "").replace(re," ") +
							' (' + num + ')' +
							'</li>'
						);
						predictTagsEgyeb++;
					}
				}
			}
		}
	}
}