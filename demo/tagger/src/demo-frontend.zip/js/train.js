var aktProb = 0.8;
var tags = [];

$( document ).ready(function() {
	$(".se-pre-con").fadeOut("slow"); 
	getModels();
	test();
	checkRequiredFields();
});

function formatTags(tags) {
    return tags.split(',').map(Function.prototype.call, String.prototype.trim).toString();   
}

function tanit(){
    $.ajax({
	   type: "GET",
	   url: "http://pi.itk.ppke.hu/hvg/backend/train",
	   contentType: 'application/json; charset=utf-8',
	   dataType: 'json',
	   success: function(result) {
            $(".train-success-msg").text(result['message']);
            $(".train-success").fadeIn("slow").delay( 2000 ).fadeOut("slow");
            getModels();
	   },
       error: function(result){
            $(".train-error-msg").text(result['responseJSON']['message']);
            $(".train-error").fadeIn("slow").delay( 2000 ).fadeOut("slow");
      }
	});
}
function restart(){
    $(".se-pre-con").show();
    $.ajax({
	   type: "GET",
	   url: "http://pi.itk.ppke.hu/hvg/backend/restart",
	   contentType: 'application/json; charset=utf-8',
	   dataType: 'json',
	   success: function(result) {
            $(".start-success-msg").text(result['message']);
            $(".start-success").fadeIn("slow").delay( 2000 ).fadeOut("slow");
	   }, 
       error: function(result){
            $(".start-error-msg").text(result['responseJSON']['message']);
            $(".start-error").fadeIn("slow").delay( 2000 ).fadeOut("slow");
      },
      complete: function(result) {
            $(".se-pre-con").fadeOut("slow"); 
      }
	});
}

function bekuld(){
	$(".se-pre-con").show();
	var cim = $('#cikk-cim').val().trim();
	var szoveg = $('#cikk-szoveg').val().trim();
	var tags = $('#cikk-tag').val().trim();
	if (cim == "" || szoveg == "" || tags == "") {
		alert('Töltse ki a kötelező mezőket! (cím, szöveg, címkék)');
        $(".se-pre-con").fadeOut("slow"); 
        return;
	}
	
	var objectToSend = new Object();
	var data = new Object();
	data.cim = cim;
	data.szoveg = szoveg;
	data.lead = $('#cikk-lead').val().trim();
	data.szerzo = $('#cikk-szerzo').val().trim();
	data.evszam = $('#cikk-evszam').val();
	data.column = $('#cikk-column').val();
	data.tags = formatTags(tags);
	objectToSend.data = [data];

	var jsonToSend = JSON.stringify(objectToSend);
	
	$.ajax({
	   type: "POST",
	   url: "http://pi.itk.ppke.hu/hvg/backend/add",
	   data: jsonToSend,
	   contentType: 'application/json; charset=utf-8',
	   dataType: 'json',
	   success: function(result) {
			torol();
            $(".add-success-msg").text(result['message']);
            $(".add-success").fadeIn("slow").delay( 2000 ).fadeOut("slow");
	   }, 
       error: function(result){
            $(".add-error-msg").text(result['responseJSON']['message']);
            $(".add-error").fadeIn("slow").delay( 2000 ).fadeOut("slow");
      },
      complete: function(result) {
            $(".se-pre-con").fadeOut("slow"); 
      }
	});
}

function getModels() {
    var modellBody = $('#model-card-body');
    var trainBody = $('#train-card-body');
    var archivBody = $('#archiv-card-body');
    
    modellBody.empty();
    trainBody.empty();
    archivBody.empty();
    
	$.ajax({
	   type: "GET",
	   url: "http://pi.itk.ppke.hu/hvg/backend/models",
	   contentType: 'application/json; charset=utf-8',
	   dataType: 'json',
	   success: function(result) {
			var models = result['data'];			
			for (i in models) {
                var status = 'success';
                var icon = 'check';
                if (models[i]['status'] == 'archiv') {
                    status = 'warning';
                    icon = 'lock';
                } else if (models[i]['status'] == 'error') {
                    status = 'danger';
                    icon = 'exclamation-triangle';
                } else if (models[i]['status'] == 'train') {
                    status = 'info';
                    icon = 'hourglass-half';
                } else if (models[i]['status'] == 'deleted') {
                    status = 'danger';
                    icon = 'skull-crossbones';
                }
                
                if (models[i]['status'] == 'archiv' || models[i]['status'] == 'deleted') {
                    archivBody.append(
                        '<div class="card mb-4 py-3 border-left-' + status + '"><div class="card-body">' +
                        '<div class="row">' +
                            '<div class="col-sm-8"><div class="text-xs font-weight-bold text-' + status + ' text-uppercase mb-1">' + models[i]['name'] + ' <span class="text-lowercase">v</span>' + models[i]['version'].toFixed(2) + '</div>' + 
                            'Módosítva: ' + models[i]['updated'] + '</div>' +
                            '<div class="col-sm-4"><a class="float-right btn btn-' + status + ' btn-icon-split"><span class="icon text-white-50">' + 
                            '<i class="fas fa-' + icon + '"></i>' + 
                            '</span><span class="text">' + models[i]['status'] + '</span></a></div>' + 
                        '</div></div></div>'
                    );
                } else if (models[i]['status'] == 'train') { 
                    trainBody.append(
                        '<div class="card mb-4 py-3 border-left-' + status + '"><div class="card-body">' +
                        '<div class="row">' +
                            '<div class="col-sm-8"><div class="text-xs font-weight-bold text-' + status + ' text-uppercase mb-1">' + models[i]['name'] + ' <span class="text-lowercase">v</span>' + models[i]['version'].toFixed(2) + '</div>' + 
                            'Módosítva: ' + models[i]['updated'] + '</div>' +
                            '<div class="col-sm-4"><a class="float-right btn btn-' + status + ' btn-icon-split"><span class="icon text-white-50">' + 
                            '<i class="fas fa-' + icon + '"></i>' + 
                            '</span><span class="text">' + models[i]['status'] + '</span></a></div>' + 
                        '</div></div></div>'
                    );
                }  else { 
                    modellBody.append(
                        '<div class="card mb-4 py-3 border-left-' + status + '"><div class="card-body">' +
                        '<div class="row">' +
                            '<div class="col-sm-8"><div class="text-xs font-weight-bold text-' + status + ' text-uppercase mb-1">' + models[i]['name'] + ' <span class="text-lowercase">v</span>' + models[i]['version'].toFixed(2) + '</div>' + 
                            'Módosítva: ' + models[i]['updated'] + '</div>' +
                            '<div class="col-sm-4"><a class="float-right btn btn-' + status + ' btn-icon-split"><span class="icon text-white-50">' + 
                            '<i class="fas fa-' + icon + '"></i>' + 
                            '</span><span class="text">' + models[i]['status'] + '</span></a></div>' + 
                        '</div></div></div>'
                    );
                }
			}
	   }
	});
}

function checkRequiredFields(){
	var cim = $('#cikk-cim').val().trim();
	var szoveg = $('#cikk-szoveg').val().trim();
	if(cim == "" || szoveg == "") {
		if(!$('#button-tag').hasClass("disabled")) {
			$('#button-tag').addClass("disabled").removeClass('btn-primary').addClass('btn-secondary');
		}
	} else {
		$('#button-tag').removeClass("disabled").removeClass('btn-secondary').addClass('btn-primary');
	}
}

$('#cikk-cim').on('keyup paste',function(){
	checkRequiredFields();
});

$('#cikk-szoveg').on('keyup paste',function(){
	checkRequiredFields();
});

$('#cikk-tag').on('keyup paste',function(){
	checkRequiredFields();
});

function test() {
	var cim = 'Beatles nélkül a világ – A zsenialitás nem szorul magyarázatra';
	var szoveg = 'Minden egyes zöldpaprikában ott rejtőzik a C-vitamin, csak elő kellett csalogatni, és amikor eljött az idő, valaki elő is csalogatta. Egy lehulló alma csak egy közönséges gyümölcs, másnak a gravitáció. A fekete lyuk mindig ott volt, ahol jelenleg Ste­phen Hawking tartózkodik, pont ez a bizonyíték mindkettő létezésére. Ha nincs Harry Potter, nincs több millió, Hermionenak öltözött vidám gyerek, de a borsodi Voldemort sem. A coke a drogbáró Pablo Escobar hívószava. Ha nincs a Beatles, a zaj mást jelentene, az Oasis nem egy zenekar, hanem a hely a sivatagban, ahová minden szomjazó vágyik. Ha nincs a Beatles, más oka lenne a szex, drog & rock and rollnak.\n\nA popuniverzum keletkezésének legújabb magyarázata az egész bolygóra kiterjedő 12 másodperces áramszünettel kezdődik. Egy kicsit szerényebb a koncepció, mint a nagy bumm, de azért így is elég messzire hallatszik. A héten mozikba kerülő játékfilm, a Yesterday készítői szívesen vállaltak néhány logikai bukfencet annak érdekében, hogy szórakoztatóan bizonyítsák egy olyan alternatív idővonal létezését, amelyen nem lelhető fel a modern zene legnagyobb hatású zenekara. Néhány pillanat alatt eltűnt a Földön eladott másfél milliárd album, az összes Penny Lane utcatábla, valamennyi liverpooli hűtőmágnes, a sárga tenger­alattjárók rajzfilmestül, az Abbey Road zebrája a „rossz oldalon” parkoló VW-val együtt.\n\nA kerékpárján hazafelé tartó Jack, akit a párhuzamos univerzumban a teremtő arra ítélt, hogy egész életében sikerületlen dalát, a Summer Songot pengesse, összeütközik egy busszal. Néhány nappal később haverjaival az újjászületését ünneplik, valaki a kezébe nyom egy gitárt, pont egy olyan Epiphone Texan modellt, amelyet Paul McCartney a komponáláskor használt, és arra kérik, játsszon valamit. Belekezd a Yesterdaybe, majd miután mindenki magához tért az első döbbenetből, megkérdezik tőle, mikor írta ezt a dalt? Azt válaszolja, nem ő írta, hanem a Beatles. Néhány kattintás után kiderül, hogy a Beatles nem létezik, dalaik egyszerűen átszálltak Jack fejébe és szívébe. A világ ugyan­olyan izgalomba jön, mint a hatvanas évek elején.\n\nA címadó dal minden idők talán legkedveltebb Beatles-slágere. Megjelenése óta olyan mágikus hatást kelt, mint az égből a földre pottyant dolgok. Milliókat érdekelt a csodálatos melódia keletkezéstörténete, de még Ian McDonald, aki 188 Beatles-dalt elemzett, dokumentált és lábjegyzetelt A fejek forradalma című könyvében, sem tud sokkal többet a misztériumról, mint bárki más. Az biztos, hogy 1965. június 14-én vették fel az Abbey Road 2-es stúdiójában, F-dúrban szól, McCartney gitárjátékát vonósok kísérik.\n\nA Help! című album B oldalán a 6. dalként rögzített Yesterday szerzőjeként a Lennon–McCartney-­kettős szerepel, de teljes egészében McCartney írta, John Lennon, Ringo Starr és George Harrison nem volt jelen a felvételkor. Egy alkalommal McCartney azt állította, akkor született, amikor a barátnője londoni lakásában lógott, máskor azt, hogy a párizsi George V luxushotelben.\n\n„Úgy érzem, évtizedek óta a fejemben volt. Nem írtam, hanem megálmodtam, egyszer csak kipottyant, mint egy tojás. Semmi egyenetlenség, sehol egy karcolás.”\n\nA Yesterday első szövegváltozata még a Scrambled Eggs címet viselte, emléket állítva annak, hogy a világon kevés vonzóbb dolog van, mint egy reggeli tojásrántotta és a paplan alól kilátszó két formás női láb. A végleges változat a Guinness Rekordok Könyve szerint minden idők legtöbbször feldolgozott dala: 3000 interpretációja ismert, a rádióállomások 7 millió alkalommal játszották, és játsszák ma is.\n\nA produkció legjobban fizetett sztárjai a Beatles-dalok voltak. Az angol gyártó cég, a filmjeivel 1992 óta hétmilliárd dollár bevételre szert tett Working Title Films tízmillió dollár jogdíjat fizetett, hogy az angol mozi két sikerembere elkészíthesse a Beatles repertoárjának legtündöklőbb darabjaira épülő meséjét. Richard Curtis korábban olyan filmek forgatókönyvét írta, mint a Négy esküvő és egy temetés, az Igazából szerelem, a Sztárom a párom és a Bridget Jones naplója. A Sekély sírhanttal feltűnést keltett, a Trainspottinggal befutott, majd a Gettómilliomossal Oscar-díjat nyert Danny Boyle rendező most annak a bemutatására vállalkozott, hogy a levitáció akár meg is történhet.\n\nA popkultúra nagy teljesítményeinek emléket állító filozofikus filmek általában tönkreteszik az emberek szórakozását. A Yesterday meg sem kísérli, hogy választ adjon egy alternatív keletkezéstörténettel kapcsolatos kérdésre, helyette azt állítja: a zsenialitás nem szorul magyarázatra.\n\n„A világóra rugóit még Isten húzta fel” – idézi az időről elmélkedve szabadon Newtont a Beatles-biblia szerzője, Ungvári Tamás –, tehát világos: istennek kell lennie annak, aki meg akarja állítani.';
	var lead = 'Ha valaki beírja a Google-keresőbe azt a szót, hogy Beatles, 30 másodperc alatt 170 millió találatot kap. A Trainspotting és a Gettómilliomos Oscar-díjas rendezőjének új filmjében egyet sem.'
	var szerzo = 'Ligeti Nagy Tamás';
	var year = 2019;
	var column = 'kult';
    var tags = 'kultúra, zene, Beatles';
	upload(cim, szoveg, lead, szerzo, year, column, tags);
}

function test2() {
	var cim = 'Itt a fordulat: feloldják a Huawei elleni szankciókat – de nagy kérdés, hogy mi történik ezután';
	var szoveg = 'A világ 19 legnagyobb fejlett és felzárkózó gazdaságát, valamint az Európai Uniót összefogó G20 csoport oszakai csúcstalálkozóján derült ki, hogy az Egyesült Államok és Kína újraindítja a kereskedelmi tárgyalásokat. Ezzel még csak keretet biztosítottak egy későbbi, lehetséges megállapodáshoz, az viszont már konkrétum, hogy Donald Trump sajtótájékoztatóján bejelentette: a kormányzat ismét lehetővé az amerikai cégek beszállítsanak a Huaweinek.\n\nAz Egyesült Államok elnöke május közepén rendelt el szükségállapotot annak érdekében, hogy "megvédje az amerikai informatikai hálózatokat a külföldi ellenségektől". Néhány nappal később teljesen egyértelművé vált, hogy az intézkedés a Huawei ellen szól. A Google kénytelen volt megvonni az Android legfontosabb részeinek használati jogát a második legnagyobb mobilgyártótól, majd több amerikai nagyvállalat, többek között az Intel és a Qualcomm is leállította a kereskedést a Huawei-jel. Ez a három cég azért érdemel külön említést, mert később éppen a két processzorgyártó és a Google kezdett erős lobbizásba annak érdekében, hogy a Trump-adminisztráció oldja fel a tiltást.\nDonald Trump a kínai-amerikai viszonyokról tartott szombati G20-as sajtótájékoztatón\n\nHogy végül miért kerülhetett erre sor, azt egyelőre nem tudni. Az biztos, hogy Trump tőle szokatlan engedékenységet mutat: a G20-találkozó előtt még – az eddig alkalmazottakon felül – 300 milliárd dollárnyi értékben emelte volna a kínai importra vonatkozó vámokat. A BBC tudósítása szerint a oszakai csúcson előbb azt mondta, hogy lekerült a napirendről a kérdés, majd egy következő sajtótájékozatón jelentette be a Huawei-embargó feloldását.\nDobja a Huawei az Androidot?\n\nAz biztos, hogy a jelenleg a Huawei telefonjait használók teljesen megnyugodhatnak, készülékeik ugyanúgy megkapnak majd mindenféle Android-frissítést és a Google által kidolgozott új funkciót, mintha mi sem történt volna. A már a boltokba került telefonok vásárlása szintén veszélytelenné vált, az amerikai tiltás feloldásának értelmében nem fordulhat elő, hogy néhány hónap múlva lekapcsolnak rajtuk ezt-azt.\n\nMás téren viszont nehéz megjósolni, hogy mi történik ezután. Az elmúlt hetek sokszor drámainak tűnő eseményei minden bizonnyal emlékezetesek maradnak a Huawei minden vezetője és munkatársa számára. Nem kizárt, hogy alapító és a menedzsment arra a következtetésre jut, hogy még egyszer nem szeretnék ilyen veszélynek kitenni a vállalatot, ezért hiába is használhatnák tovább a korábbi feltételekkel az Androidot, végül nem így tesznek majd. Reális lehetőségről van szó, hiszen a Huawei – éppen az évek óta lebegtetett amerikai intézkedések miatt – régóta munkálkodik egy saját platformon, melyen ezekben a hetekben már az utolsó simításokat végezték. A platform állítólag 60 százalékkal gyorsabb az Androidnál, ráadásul már más kínai mobilgyártók is elgondolkodtak azon, hogy a Huawei rendszerére cserélik le az Androidot.\n\nPersze akármilyen gyors is a Huawei saját rendszere és akárhány kisebb kínai gyártó áll is mögé, akkor sem lenne egyszerű bevezetni. Ahogy az embargó elrendelése utáni elemzésünkben megírtuk, hasonló próbálkozásba már maga a Microsoft is belebukott.\n\nA vállalat ikonikus társalapítója, Bill Gates épp a minap fogalmazta meg véleményét, miszerint az okostelefonok világában az Apple mellett egyetlen hely kiadó, ezt birtokolja a Google-féle Android. Gates élete legnagyobb hibájának tartja, hogy a Microsoft anno lecsúszott a hely megszerzéséről. Kérdés, hogy a Huawei-alapító Zsen Cseng-fej – aki szerint az USA alábecsüli vállalata erejét – reális lehetőségként tekint-e arra, hogy megpróbálja azt, ami Gatesnek és Microsoftnak anno nem sikerült.';
	var lead = 'Kihátrált Donald Trump amerikai elnök a Huawei-jel szembeni embargóból. Nagy kérdés, hogy hogyan reagál erre az idő közben új operációs rendszerét már javában tesztelő gyártó.'
	var szerzo = 'Balogh Csaba';
	var year = 2019;
	var column = 'tech';
    var tags = 'gazdaság, Huawei';
	upload(cim, szoveg, lead, szerzo, year, column, tags);
}

function test3() {
	var cim = 'A román kormányfő lett a szociáldemokrata párt elnöke';
	var szoveg = 'A kongresszust azt követően szervezték meg, hogy május végén Liviu Dragnea volt pártelnököt jogerősen letöltendő börtönbüntetésre ítélték egy korrupciós perben, ezért börtönbe kellett vonulnia. Azóta Dancila volt a párt ideiglenes elnöke, akinek három kihívója volt a szombati megmérettetésen.\n\nA pártelnököt egy körben választották, így az nyert, aki a legtöbb szavazatot kapta. A szavazás ily módon való lebonyolításáról pénteken határozott a párt országos ügyvezető testülete és megfigyelők szerint ez Dancilának kedvezett. A kormányfő a román média értesülései szerint 2828 szavazatot kapott, második helyen Liviu Plesoianu parlamenti képviselő végzett 715 vokssal.';
	var lead = 'Viorica Dancila miniszterelnököt választották elsöprő többséggel a román Szociáldemokrata Párt (PSD) elnökévé a legnagyobb kormánypárt szombati tisztújító kongresszusán.'
	var szerzo = 'mti';
	var year = 2019;
	var column = 'világ';
    var tags = 'politika, Románia, választás';
	upload(cim, szoveg, lead, szerzo, year, column, tags);
}

function test4() {
	var cim = 'Hosszú Katinka: Annyi hülyeséget csináltam';
	var szoveg = 'Az úszó tíz évvel ezelőtt, 2009-ben szerezte meg első világbajnoki címét, most összegezte az elmúlt évtizedét a Nemzeti Sportnak adott interjújában. Csúcsok, lejtők, hegymenet és pofonok is előkerülnek.\n\nHosszú Katinka azt mondta a beszélgetésben, hogy a vagányság már akkor is, tíz évvel ezelőtt is benne volt, „az, hogy álljunk fel a rajtkőre, és nézzük meg, ki mit tud! Enélkül nem is lehet világbajnokságot nyerni.” De az akkori úszóban nem volt fegyelmezettség és tudatosság, ezt maga vallja be. Felidéz egy történetet, a 2008-as olimpiát megelőző edzőtábort Dél-Afrikából, amikor nem volt hajlandó úszószemüveget felvenni, hogy egyenletesen barnuljon le.\n\n„Ezt a történetet mindenki szereti. Egyébként igaz. Lázadás volt. Amikor a nagypapámmal készültem, és országos csúcsokat úsztam a korosztályomban, megvolt a célom, mégpedig hogy tizenöt évesen olimpiai bajnok leszek. Tizenhét-tizennyolc évesen úgy éreztem, hogy kudarcot vallottam, hiszen nem jöttek úgy az eredmények, ahogy szerettem volna, ezért azt éreztem, nem az vagyok, aki lenni szeretnék. Ráadásul tini is voltam – így lázadtam vagy védtem magam a kudarctól: közöltem mindenkivel, hogy engem senki se szólítson úszónak! Én nem vagyok úszó, az úszás a hobbim, csak az, amit csinálok, de nem én magam.”\n\nMa is makacs még, mondja, de akkor még nem tudtak vele mit kezdeni. Szokta is mondani szüleinek, reméli, gyermekei majd kevéssé lesznek nehéz természet. Ma már egyébként eszébe jut az anyaság, három vagy több gyermeket szeretne. Az elmúlt tíz évben voltak kisebb és nagyobb pofonok is, vallja, a legrosszabb és legnehezebb, ha „olyan pofont kapsz, amelyről nem tudod, mit is kellene belőle tanulnod.”\n\nKorábban akkor is elpirult, amikor valaki egy családi ebéden szólt hozzá, annyira szégyellős volt, ma pedig már motivációs előadásokat tart. „Sokszor szándékoson lavírozom magam kellemetlen helyzetbe azért, hogy tanuljak. Ha kényelmes vagy, sosem fejlődsz. Ezért is lesz más a tokiói Katinka – érettebb, tapasztaltabb vagyok.”\n\nNem tudja, kívülről látni-e ebből valamit, ő belül lett teljesen más. „Kívülről tök egyszerűnek és könnyűnek tűnik az elmúlt egy évem is, hiszen volt egy üresjárat, magánéleti és szakmai válság, edzőváltás, most meg itt vagyok, és megint nyerek. Ennyi. És közben minden más. Másként megyek oda egy versenyszám rajtjához, más a technikám, másként kerülök a zónába, másra gondolok úszás közben. Igen, azon a szinten vagyok vagy még magasabban, mint voltam korábban, csakhogy teljesen más utat jártam be, mint azt megelőzően.”\n\nHegyet mászott az elmúlt évben, de sokkal erősebb lett – szögezi le.\n\nNem viselte meg, hogy májusban 30 éves lett. „Most érzem magam a legjobban, már tudom, ki vagyok. Eddig ez nem így volt, huszonévesen azt sem tudja az ember, kicsoda, mit képvisel, rángatnak ide-oda mások, ezt mondd, azt csináld... Ma már ez nem így van. Már tudom, ki vagyok, mit szeretnék és hogyan.” Most kezdte el tisztelni és szeretni önmagát.\n\nVégül az újságíró rákérdez, bánt-e meg valamit az elmúlt 10 évben:\n\nHosszan sorolhatnám, rengeteg ilyen van – annyi hülyeséget csináltam! A mostani fejemmel sok mindent másként csinálnék, és nyilván akkor a pályafutásom is másként alakult volna. Viszont az már a múlt, nem is lehet rajta változtatni, de nem is kell. Ezek a hülyeségek, rossz döntések, hibás lépések mind kellettek ahhoz, hogy most az legyek, aki.';
	var lead = 'Tíz éve még úszószemüveget sem volt hajlandó felvenni, hogy egyenletesen barnuljon.'
	var szerzo = 'hvg.hu';
	var year = 2019;
	var column = 'sport';
    var tags = 'sport, úszás, Hosszú Katinka';
	upload(cim, szoveg, lead, szerzo, year, column, tags);
}

function test5() {
	var cim = 'A jó apa-gyerek kapcsolat nélkülözhetetlen az önbizalomhoz';
	var szoveg = 'Évtizedek kutatásai bizonyítják a mai napon ünnepelt apák központi szerepét az egészséges önértékelésben. Főleg a lányok önvédését alapozhatja meg.\n\n„Te egy alma vagy” – mondja Erlend Loe norvég író Doppler hazatér című, 2017-es könyvében az apa a furcsa alakokkal randizgató kamaszlányának, csak úgy, tévénézés közben. A párbeszéd apa és lánya között így folytatódik:\n\n„Miért mondod ezt?”; „Azért. Csak úgy mondom. Mert alma vagy. Valakinek meg kell mondania. Egy csodás, piros, fényes alma vagy. De amikor valaki beleharap egy almába, elkezdődik a rothadás. Akkor megbarnul, fonnyadt lesz. És kicsivel később már nem is ízlik annyira.”\n\nÍrói túlzás vagy tudományos értékű megfigyelés? Olvassuk el a magyar felnőtt nő, Anna történetét: „Apám nagyon szeretett, de amikor kamasz lettem, ostobán viselkedett. Nem akart elengedni otthonról, csak hazudozva találkozhattam férfiakkal. Az eredmény? Még felnőttkoromban is görcsbe rándult a gyomrom, amikor a leendő férjemmel találkozgattunk. Az önbizalmam nulla volt, pedig csinos nő voltam. Azt gondolom, hogy az apám rosszallása elég volt ahhoz, hogy évekre elbizonytalanodjak.”\n\nAnna példája nem egyedi. Caroline Payne-Purvisnek, a Floridai Egyetem munkatársának 2014-es beszámolója mintha csak Annáról és a sorstársairól szólna. Kutatásában tizenéves lányok szexuális életét, ezen belül is rizikómagatartását vizsgálta. Eredményei egyértelművé tették, hogy ha egy tinédzserlány jó kapcsolatot ápol az apjával, kisebb a kockázata annak, hogy nem megfelelő partnerekkel randevúzik. Úgy is fogalmazhatunk, hogy egészséges önbizalmuk és stabil nemi identitásuk megvédi őket attól, hogy „bárkinek” odaadják magukat.\n\nHölgyek hormonjai\n\nDe hogyan is működhet ez a titokzatos apai hatás? Lehetséges lenne, hogy önmagában az apa viselkedése megerősítheti vagy tönkre teheti egy fiatal lány önértékelését? Jennifer Byrd-Craven amerikai pszichológus és munkatársai elhatározták, hogy kicsit jobban utánanéznek ennek az apa-lány dolognak. Kutatásukat nem bízták a véletlenre, egyenesen fiatal hölgyek hormonváltozásait vették górcső alá.\n\nAz eredmények a kutatók igyekezetét igazolták. 2012-ben publikált írásukban kiemelték, hogy azok a lányok, akiknek az apjukkal jó kapcsolatuk volt, bizony már a reggeli ébredést követően is alacsonyabb stresszhormonszintet mutattak. A kutatók megjegyzik: a jó apai kapcsolatú lányok stresszes helyzetben, illetve probléma megvitatása közben is megőrizték nyugalmukat. A rossz apai kapcsolatúak stresszhormonszintje a konfliktusok esetén megemelkedett, stresszhelyzetben pedig gyakrabban magukba zárkóztak.\n\nSzeretet és etetés\n\nSzámos kutatás utal arra, hogy a korai apai jelenlét csökkenti a kamaszlányok szorongását, növeli önérzetüket és általában véve szociális készségeiket. Melissa Home, a Georgetowni Egyetem pszichológusa 2011-ben kamaszlányok társkapcsolati boldogulását vizsgálva fogalmazta meg, hogy a lányok önbizalma, a párkapcsolaton belüli alárendelődése elsősorban az apjukhoz fűződő kapcsolat minőségétől függ.\n\nÉs ha már az almával kezdtük, folytassuk az étkezéssel. A Rutgers Egyetem 2014-ben megjelent kutatása szerint még a gyermeküktől külön élő apák is jelentősen befolyásolják gyermekeik étkezési szokásait, ha több időt töltenek gyermekeikkel, illetve a szeretetüket gyakrabban kifejezik. Az apai törődés stabilizálta a gyerekek étkezési szokásait, akkor is, ha az apa nem volt jelen.';
	var lead = 'Évtizedek kutatásai bizonyítják a mai napon ünnepelt apák központi szerepét az egészséges önértékelésben. Főleg a lányok önvédését alapozhatja meg. '
	var szerzo = 'HVG Extra Pszichológia';
	var year = 2019;
	var column = 'Pszichológia magazin';
    var tags = 'pszichológia, apa, család';
	upload(cim, szoveg, lead, szerzo, year, column, tags);
}

function torol() {
	upload("", "", "", "", "", "");
}

function upload(cim, szoveg, lead, szerzo, year, column, tags) {
	$('#cikk-cim').val(cim);
	$('#cikk-szoveg').val(szoveg);
	$('#cikk-lead').val(lead);
	$('#cikk-szerzo').val(szerzo);
	$('#cikk-evszam').val(year);
	$('#cikk-column').val(column);
	$('#cikk-tag').val(tags);
}