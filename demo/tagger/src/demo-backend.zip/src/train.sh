#!/bin/bash

datafolder="$1"
container="$2"
corpus="$3"
model="$4"
modelfolder="$5"
fasttext="$6"

sort -u "$datafolder/$container" > "$datafolder/dump"
cat "$datafolder/dump" >> "$datafolder/$corpus"
echo "" > "$datafolder/dump"
echo "" > "$datafolder/$container"

"$fasttext" supervised -input "$datafolder/$corpus" -output "$modelfolder/$model" -lr 0.2 -epoch 30 -wordNgrams 3 -bucket 200000 -dim 300 -loss one-vs-all
#/fastText/fasttext supervised -input /dataDir/hetilap.1.10.hetilapmodel.txt -output /modelDir/hetilap.1.10.hetilapmodel.txt.model -lr 0.2 -epoch 30 -wordNgrams 3 -bucket 200000 -dim 300 -loss one-vs-all
