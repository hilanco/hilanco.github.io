import re
import json
import copy
import datetime
import os
from flask import jsonify, Response
from subprocess import Popen, PIPE
from multiprocessing import Process, Manager
import threading
import hu_core_ud_lg
import sentencepiece as spm

class Tagger:

    def __init__(self):        
        self._setVariables()
        self._loadConfigFile()
        self._startTruecase()
        #self._checkModels()
        print("************ SERVER STARTED **************")
        pass
        
    def exceptionResponseDecorator(func):
        def runFunction(self, content=None, *args, **kwargs):
            try:
                if content == None:
                    return func(self, *args, **kwargs)
                else:
                    return func(self, content, *args, **kwargs)
            except LogicException as le:
                return self._setResponse(400, le.message)
            except (FileNotFoundError, IOError) as e:
                return self._setResponse(400, str(e))
            except Error as e:
                return self._setResponse(500, str(e))
        return runFunction

    @exceptionResponseDecorator
    def tag(self, content):
        return self._tagging(content)

    @exceptionResponseDecorator
    def models(self):
        return self._getModels()
    
    def _getModels(self):
        #self._checkModels()
        return self._setResponse(200, "Modellek lekérdezve!", self.data['models'])

    def _setVariables(self):
        self.sp = spm.SentencePieceProcessor()
        self.nlpSpacy = hu_core_ud_lg.load()
        self.data = {}
        self.modelDir = "/models"
        self.dataDir = "/data"
        self.fastText = "/fastText/fasttext"
        self.scriptDir = "/scripts"
        self.configFile = "config.json"
        self.container = "container"

    def _loadConfigFile(self):
        modelList = []        
        with open(self.configFile) as config_file:
            self.data = json.load(config_file)
            
            if self.data['modelDir']:
                self.modelDir = self.data['modelDir']
                
            if self.data['dataDir']:
                self.dataDir = self.data['dataDir']
                
            for model in self.data['models']:
                if model['status'] == "online":
                    modelPath = self._generateModelPath(model)
                    modelList.append((model['name'], modelPath))
                    print(modelPath + " model loaded")

        self.sp.Load(self.modelDir + "/mup32.model")
        self.taggerDict = {}
        for name, model in modelList:
            command = self.fastText + " predict-prob " + model + " - 20"
            # print(command)
            self.taggerDict[name] = Popen([command], shell=True, stdin=PIPE, stdout=PIPE, close_fds=True)
    
    def _startTruecase(self):
        # Kisbetűsítő elindítása
        command = "perl " + self.scriptDir + "/truecase.perl --model " + self.modelDir + "/truecaseModel.hu -b"
        self.taggerDict['truecase'] = Popen([command], shell=True, stdin=PIPE, stdout=PIPE, close_fds=True)

    def _setResponse(self, code, message="", data=None):
        content = json.dumps({'message': message, 'data': data})
        return Response(content, status=code, mimetype="application/json", content_type="application/json; charset=utf-8")
    
    def _generateModelPath(self, model):
        modelPath = self._generateModelDir(model)
        modelPath += "/" + self._generateModelName(model)
        modelPath = modelPath.replace('//', '/')
        return modelPath
        
    def _generateModelDir(self, model):
        modelPath = self.modelDir + '/'
        if 'path' in model and model['path']:
            modelPath += model['path']
        modelPath = modelPath.replace('//', '/')
        return modelPath

    def _generateModelName(self, model):
        return str(model['version']) + "." + model['filename'] + ".model.bin"
        
    def __del__(self):
        for key in self.taggerDict:
            print(self.taggerDict[key].communicate())
        pass

    def _analyse(self, parser, inputLine):
        parser.stdin.write(inputLine.encode("utf-8"))
        parser.stdin.write(b"\n")
        parser.stdin.flush()
        out = parser.stdout.readline().strip()
        return out.decode("utf-8")

    def _tagging(self, content):
        cikkek = content['data']
        modelStr = content['model']
        model = self.taggerDict[modelStr]

        for cikk in cikkek:
            szoveg = cikk['cim'] + " $$$ " + cikk['lead'] + " $$$ " + cikk['szoveg']
            # Nyelv feldolgozó, amit a mondatokra bontás során használunk
            doc = self.nlpSpacy(szoveg)
            #for sent in doc.sents:
            #    print("TEXT",sent.text)
            #    if sent.text.strip() != "":
            #        print(self._analyse(self.taggerDict["truecase"], sent.text))
            #    else:
            #        print("")

            encodedText = self.sp.EncodeAsPieces(szoveg)
            szoveg = ' '.join(encodedText)
            # print(szoveg)
            re.sub('\s+', ' ', szoveg)
            szoveg = szoveg.strip()
            szoveg = "column__" + cikk['column'].replace(' ', '@@').lower() + " year__" + cikk['evszam'] + " author__" + \
                     cikk['szerzo'].replace(' ', '@@').lower() + " $$$ " + szoveg
            # print(szoveg)
            tags = self._analyse(model, szoveg)
            tags = tags.split(" ")
            tags = list(sorted(zip(tags[::2], tags[1::2]), key=lambda x: x[1], reverse=True))
            cikk['tags'] = tags
        return self._setResponse(200, "Címkézés sikeres!", cikkek)
    
    '''
    
    def _checkModels(self):
        for model in self.data['models']:
            if not os.path.exists(self._generateModelPath(model)):
                if model['status'] == "online":
                    model['status'] = "error"
                elif model['status'] == "archiv":
                    model['status'] = "deleted"

        with open(self.configFile, 'w') as jsonFile:
            json.dump(self.data, jsonFile)
            
    
    @exceptionResponseDecorator
    def add(self, content):
        return self._adding(content)
        
    @exceptionResponseDecorator
    def train(self):
        return self._training()
        
    def restart(self):
        command = f"docker restart e4b7a70f4ebb"
        restartDocker = Popen([command], shell=True, stdin=PIPE, stdout=PIPE, close_fds=True)
        return self._setResponse(200, "Szerver újraindítva")
        
    def _adding(self, content):
        cikkek = content['data']
        path = self.dataDir + '/' + self.container
        path = path.replace('//', '/')
        # f = open(path, "a+")
        with open(path, "a+") as containerFile:
            for cikk in cikkek:
                szoveg = cikk['cim'] + ' $$$ ' + cikk['lead'] + ' $$$ ' + cikk['szoveg']
                # Nyelv feldolgozó, amit a mondatokra bontás során használunk
                #doc = self.nlpSpacy(szoveg)
                #for sent in doc.sents:
                #    print("TEXT",sent.text)
                #    if sent.text.strip() != "":
                #        print(self._analyse(self.taggerDict["truecase"], sent.text))
                #    else:
                #       print("")

                encodedText = self.sp.EncodeAsPieces(szoveg)
                szoveg = " ".join(encodedText)
                # print(szoveg)
                re.sub('\s+', ' ', szoveg)
                szoveg = szoveg.strip()
                szoveg = "column__" + cikk['column'].replace(' ', '@@').lower() + " year__" + cikk['evszam'] + " author__" + \
                         cikk['szerzo'].replace(' ', '@@').lower() + " $$$ " + szoveg
                tags = cikk['tags']
                cimke = ''
                for tag in tags.split(','):
                    cimke += '__label__' + tag.replace(' ', '@@') + " "
                line = cimke + szoveg
                containerFile.write('\n' + line)
        #f.close()
        return self._setResponse(200, "Új cikk hozzáadva!")

    def _generateId(self):
        max = 0
        for model in self.data['models']:
            if model['id'] > max:
                max = model['id']
        return max + 1
        
    def _createNewModel(self, model):
        newModel = copy.deepcopy(model)
        newVersion = round(float(model['version']), 2)
        newVersion += 0.1
        newId = self._generateId()
        newModel['version'] = newVersion
        newModel['status'] = "train"
        return newModel
        
    def _callFasttextForNewModel(self, model):
        corpusName = model['corpus']
        modelName = self._generateModelName(model)[:-4]
        modelDir = self._generateModelDir(model)
        print(f"A {modelName} modellt elkezdtük tanítani a {corpusName} korpuszból!")
        command = f"{self.scriptDir}/train.sh {self.dataDir} {self.container} {corpusName} {modelName} {modelDir} {self.fastText}"
        process = Popen([command], shell=True, stdin=PIPE, stdout=PIPE, close_fds=True)
        process.wait()
        if process.returncode == 0:
            print(f"A {modelName} modell tanítása sikeresen befejeződött!")
        else:
            print(f"A {modelName} modell tanítása során hiba lépett fel!")
        return
    
    def _trainNewModel(self, models):
        trainList = []
        for model in models:
            t = threading.Thread(target=self._callFasttextForNewModel, args=(model,))
            t.start()
            trainList.append(t)
        for t in trainList:
           t.join()
        return
        
    
    def _updateModelsInConfig(self, newModel):
        date = datetime.datetime.now()
        for model in self.data['models']:
            if model['name'] == newModel['name']:
                if model['status'] == "online":
                    model['status'] = "archiv"
                    model['updated'] = str(date)
                elif model['status'] == "train":
                    model['status'] = "online"
                    model['updated'] = str(date)
        return
    
    def _hasTrainingModel(self):
        for model in self.data['models']:
           if model['status'] == 'train':
                return True
        return False
    
    def _training(self):
        self._checkModels()
        if self._hasTrainingModel():
            raise LogicalException("Már folyamatban van egy tanítás!")
            
        trainWorker = threading.Thread(target=self._trainingThread)
        trainWorker.start()
        return self._setResponse(200, "A tanítást elindítottuk!")
    
    def _trainingThread(self):
        time = datetime.datetime.now()
        newModels = []
        for model in self.data['models']:
            if model['status'] == "online":
                newModel = self._createNewModel(model)
                self.data['models'].append(newModel)
                newModels.append(newModel)

        with open(self.configFile, 'w') as jsonFile:
            json.dump(self.data, jsonFile)
        
        self._trainNewModel(newModels)
        
        for model in newModels:
            self._updateModelsInConfig(model)
        
        with open(self.configFile, 'w') as jsonFile:
           json.dump(self.data, jsonFile)
        
        print(f"A tanítás befejeződött! A tanítás ideje: {datetime.datetime.now()- time}")
        return
    '''

class LogicalException(Exception):
    def __init__(self, message):
        self.message = message
        super(LogicalException, self).__init__(message)
