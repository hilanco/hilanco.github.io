from flask import Flask, request
from tagger import Tagger

app = Flask(__name__)
tagger = Tagger()

@app.route('/tag', methods = ['POST'])
def tag():
   content = request.get_json()
   return tagger.tag(content)

@app.route('/models')
def models():
   return tagger.models()

'''
@app.route('/train')
def train():
   return tagger.train()

@app.route('/restart')
def restart():
   return tagger.restart()
   
@app.route('/add', methods = ['POST'])
def add():
   content = request.get_json()
   return tagger.add(content)
'''

if __name__ == '__main__':
   app.run()
